# Monthly Money (Android)

A simple offline monthly salary and expense tracker in Bangladeshi Taka (৳), with category summaries and a calculator.

## Build the APK using GitHub (no Android Studio required)
1. Create a free repository on GitHub.
2. Upload **all files and folders inside this project** to the repository (keep the `.github/workflows/build.yml` file and its folder structure).
3. Open the repository's **Actions** tab and select **Build Monthly Money APK**.
4. Select **Run workflow**. Wait for the workflow to finish successfully.
5. Open the completed workflow run, scroll to **Artifacts**, and download `MonthlyMoney-APK`.
6. Extract the downloaded ZIP. Install `app-debug.apk` on your Android phone. Android may ask you to allow installation from that source.

The app stores salary and spending data locally on the phone. It does not require an account or internet connection for normal use.
