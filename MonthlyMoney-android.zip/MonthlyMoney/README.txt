MONTHLY MONEY - Android project

BUILD THE APK (Android Studio):
1. Install Android Studio (free) on a computer.
2. File > Open > choose this MonthlyMoney folder. Wait for Gradle sync.
   (If it asks to use a Gradle version or JDK, accept; JDK 17 is needed.)
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Click "locate" in the popup. The file is app/build/outputs/apk/debug/app-debug.apk
5. Copy the APK to your phone, open it, and allow "Install unknown apps" if asked.

The app itself is app/src/main/assets/index.html. Edit it to change the app.
Data is stored on the phone only. No ads, no internet permission.
